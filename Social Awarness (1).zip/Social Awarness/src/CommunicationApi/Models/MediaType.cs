namespace CommunicationApi.Models
{
    public enum MediaType
    {
        Text,
        Image,
        Video
    }
}