﻿namespace CommunicationApi.Models
{
    public enum BoxStatus
    {
        Registered,
        Activated
    }
}