namespace CommunicationApi.Models
{
    public class WhatsappResponse
    {
        public string ResponseMessage { get; set; }
        public bool Accepted { get; set; }
        public string ImageUrl { get; set; }
    }
}