namespace CommunicationApi.Models
{
    public class WhatsappMediaItem
    {
        public string Url { get; set; }
        public string ContentType { get; set; }
    }
}