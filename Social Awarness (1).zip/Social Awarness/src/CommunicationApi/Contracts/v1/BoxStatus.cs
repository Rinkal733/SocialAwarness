﻿namespace CommunicationApi.Contracts.v1
{
    public enum BoxStatus
    {
        Registered,
        Activated
    }
}